# 0.2.0

Updated for AtO v1.7.22

# 0.1.1

Update to hopefully fix mod manager downloading.

# 0.1.0

Initial pre-release.
