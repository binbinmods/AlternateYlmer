<!-- # 0.2.0 -->

<!-- Made it so the proper versions of the boss spawn. Previously would only spawn the M0 version.

Should work with Obeliskial Content v1.5.6+ and should also work with prior versions. -->

# 0.1.3

Fixed an issue with Proliferate being able to be acquired by heroes.

# 0.1.2

Bug fix to prevent game from crashing when entering boss fight

# 0.1.1

Nerfed Montshek's damage

Nerfed all bosses speed and resists

Prevented Montshek from infinitely summoning

# 0.1.0

Initial pre-release.
